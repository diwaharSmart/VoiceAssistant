from django.contrib import admin
from metrics.models import *
# Register your models here.
admin.site.register(APIMetric)